$('a').on('click', function(e){
    console.log("here");
 e.preventDefault();
 if($(this).attr('href'))
 {
    alert($(this).attr('href'));
 }   
})