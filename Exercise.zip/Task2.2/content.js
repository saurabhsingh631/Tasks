$('a').on('click', function(e){
    e.preventDefault();
    var link = $(this).attr('href');
    if(link)
    {
        window.open(link, link, "width=500,height=500");
    }   
    
})
