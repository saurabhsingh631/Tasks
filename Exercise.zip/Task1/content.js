let articals = $('article').length;
let images = $('img').length;
let exit_link = $("a[target=_blank]").length

alert('Articals are '+articals+' Images are '+images+' Exit links are '+exit_link)